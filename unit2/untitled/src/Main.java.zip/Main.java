public class Main {
    public static void main(String[] args) {
       whatmonth("march");
    }
    static void whatmonth(String month){
        switch(month){
            case "january":System.out.println("31");
                break;
            case "febuary":System.out.println("28");
                break;
            case "march":System.out.println("31");
                break;
            case "april":System.out.println("30");
                break;
            case "may":System.out.println("31");
                break;
            case "june":System.out.println("30");
                break;
            case "july":System.out.println("31");
                break;
            case "august":System.out.println("31");
                break;
            case "september":System.out.println("30");
                break;
            case "october":System.out.println("31");
                break;
            case "november":System.out.println("30");
                break;
            case "december":System.out.println("31");
                break;

        }
    }
}