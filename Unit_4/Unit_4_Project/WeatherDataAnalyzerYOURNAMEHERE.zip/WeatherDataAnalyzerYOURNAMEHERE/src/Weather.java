import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Weather {
    public static void main(String[] args){
        //The data array below is populated with contents from "Data.txt"
        //It contains 365 days of data from the year 2000
        String[] data = readData();

    }

    // DO NOT MODIFY THE readData() METHOD BELOW

    public static String[] readData() {
        String[] data = new String[365];
        try {
            Scanner scan = new Scanner(new File("Data.txt"));
            int i =0;
            while (scan.hasNextLine() && i < 365) {
                data[i] = scan.nextLine();
                i++;
            }
        } catch (IOException e){
            System.out.println("ERROR READING FILE!");
        }
        return data;
    }

}
